import { ComponentFactoryResolver, ComponentRef, ApplicationRef, Injector } from '@angular/core';
import { BasePortalHost, ComponentPortal, TemplatePortal } from './portal';
/**
 * A container outside the Angular application context, but co-located within the same
 * document, used for containing a collection of hidden DrawCanvas/DrawCanvasRef pairing of
 * a Component and its control Service.
 *
 * This is the only part of this application that should ever directly touch DOM.
 */
export declare class DrawCanvasHost {
    private _hostDomElement;
    private _componentFactoryResolver;
    private _appRef;
    private _defaultInjector;
    constructor(private _hostDomElement: Element, private _componentFactoryResolver: ComponentFactoryResolver,
      private _appRef: ApplicationRef, private _defaultInjector: Injector) {

    }
    /**
     * Attach the given ComponentPortal to DOM element using the ComponentFactoryResolver.
     * @param portal Portal to be attached
     */
    attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
    /**
     * Attaches a template portal to the DOM as an embedded view.
     * @param portal Portal to be attached.
     */
    attachTemplatePortal(portal: TemplatePortal): Map<string, any>;
    /**
     * Clears out a portal from the DOM.
     */
    dispose(): void;
    /** Gets the root HTMLElement for an instantiated component. */
    private _getComponentRootNode(componentRef);
}
