import {PortalHost} from "@angular/material";
import {CanvasPoolHost} from "./canvas-pool-host.value";
/**
 * Created by jheinnic on 1/2/17.
 */
export class Portal<T> {
  private _attachedHost;
  /** Attach this reference to a container. */
  attach(host: CanvasPoolHost): T;
  /** Detach this portal from its host */
  detach(): void;
  /** Whether this portal is attached to a host. */
  readonly isAttached: boolean;
  /**
   * Sets the PortalHost reference without performing `attach()`. This is used directly by
   * the PortalHost when it is performing an `attach()` or `detach()`.
   */
  setAttachedHost(host: PortalHost): void;
}
/**
 * A `ComponentPortal` is a portal that instantiates some Component upon attachment.
 */
export declare class ComponentPortal<T> extends Portal<ComponentRef<T>> {
  /** The type of the component that will be instantiated for attachment. */
  component: ComponentType<T>;
  /**
   * [Optional] Where the attached component should live in Angular's *logical* component tree.
   * This is different from where the component *renders*, which is determined by the PortalHost.
   * The origin necessary when the host is outside of the Angular application context.
   */
  viewContainerRef: ViewContainerRef;
  /** [Optional] Injector used for the instantiation of the component. */
  injector: Injector;
  constructor(component: ComponentType<T>, viewContainerRef?: ViewContainerRef, injector?: Injector);
}
