/**
 * Created by jheinnic on 1/2/17.
 */
import {Injector, Injectable} from "@angular/core";
import {Overlay, ComponentType, MdDialogConfig, MdDialogRef} from "@angular/material";
import {DrawCanvasConfig} from "./draw-canvas-config.value";

import Immutable = require('immutable');

/**
 * Service to open DrawCanvas Components to serve as containers for image data that an
 * application is working with, but may not necessarily need displayed at all times.
 */
@Injectable()
export declare class DrawCanvasService {
  private _injector;
  /** Keeps track of the currently-open draw canvases. */
  private _openDrawCanvases;

  constructor( _injector: Injector);

  /**
   * Opens a draw canvas of a specified sizes, associates it with an identifier,
   * and returns it to the caller through a wrapping reference object.
   *
   * @param config Extra configuration options.
   * @returns Reference to the newly-opened canvas.
   */
  open<T>(component: ComponentType<T>, config?: DrawCanvasConfig): DrawCanvasRef {
    var _this = this;
    config = this._applyConfigDefaults(config);
    var canvasContainer = this._getCanvasContainer(config);
    var canvasRef = this._attachCanvasContent(canvasContainer, config);
    this._openDrawCanvases.push(config.identity, canvasRef);
    canvasRef.afterClosed().subscribe(function () { return _this._removeDrawCanvas(canvasRef); });
    return canvasRef;
  };

  private _applyConfigDefaults(config: ) {

  }
  /**
   * Closes all of the currently-open dialogs.
   */
  MdDialog.prototype.closeAll = function () {
  var i = this._openDialogs.length;
  while (i--) {
  // The `_openDialogs` property isn't updated after close until the rxjs subscription
  // runs on the next microtask, in addition to modifying the array as we're going
  // through it. We loop through all of them and call close without assuming that
  // they'll be removed from the list instantaneously.
  this._openDialogs[i].close();
}
};
/**
 * Creates the overlay into which the dialog will be loaded.
 * @param dialogConfig The dialog configuration.
 * @returns A promise resolving to the OverlayRef for the created overlay.
 */
MdDialog.prototype._createOverlay = function (dialogConfig) {
  var overlayState = this._getOverlayState(dialogConfig);
  return this._overlay.create(overlayState);
};
/**
 * Attaches an MdDialogContainer to a dialog's already-created overlay.
 * @param overlay Reference to the dialog's underlying overlay.
 * @param config The dialog configuration.
 * @returns A promise resolving to a ComponentRef for the attached container.
 */
MdDialog.prototype._attachDialogContainer = function (overlay, config) {
  var viewContainer = config ? config.viewContainerRef : null;
  var containerPortal = new ComponentPortal(MdDialogContainer, viewContainer);
  var containerRef = overlay.attach(containerPortal);
  containerRef.instance.dialogConfig = config;
  return containerRef.instance;
};
/**
 * Attaches the user-provided component to the already-created MdDialogContainer.
 * @param component The type of component being loaded into the dialog.
 * @param dialogContainer Reference to the wrapping MdDialogContainer.
 * @param overlayRef Reference to the overlay in which the dialog resides.
 * @returns A promise resolving to the MdDialogRef that should be returned to the user.
 */
MdDialog.prototype._attachDialogContent = function (component, dialogContainer, overlayRef) {
  // Create a reference to the dialog we're creating in order to give the user a handle
  // to modify and close it.
  var dialogRef = new MdDialogRef(overlayRef);
  if (!dialogContainer.dialogConfig.disableClose) {
    // When the dialog backdrop is clicked, we want to close it.
    overlayRef.backdropClick().first().subscribe(function () { return dialogRef.close(); });
  }
  // Set the dialogRef to the container so that it can use the ref to close the dialog.
  dialogContainer.dialogRef = dialogRef;
  // We create an injector specifically for the component we're instantiating so that it can
  // inject the MdDialogRef. This allows a component loaded inside of a dialog to close itself
  // and, optionally, to return a value.
  var dialogInjector = new DialogInjector(dialogRef, this._injector);
  var contentPortal = new ComponentPortal(component, null, dialogInjector);
  var contentRef = dialogContainer.attachComponentPortal(contentPortal);
  dialogRef.componentInstance = contentRef.instance;
  return dialogRef;
};

/**
 * Removes a dialog from the array of open dialogs.
 * @param dialogRef Dialog to be removed.
 */
private _removeOpenCanvas = function (canvasRef) {
  var index = this._openDialogs.indexOf(canvasRef);
  if (index > -1) {
    this._openDialogs.splice(index, 1);
  }
}


