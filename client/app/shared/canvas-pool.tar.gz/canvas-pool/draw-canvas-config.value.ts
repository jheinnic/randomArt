import * as uuid from "uuid";
/**
 * Configuration for opening a draw canvas with the CanvasPool service.
 */
export class DrawCanvasConfig {
  // viewContainerRef?: ViewContainerRef;
  idenitity: string;
  /** Externalized identity as understood by an end user */
  displayName: string;
  /** Width of the dialog. */
  width?: number;
  /** Height of the dialog. */
  height?: number;
  /** Position overrides. */
  mediaSource: any;
}
