import { OverlayRef } from '../core';
import { Observable } from 'rxjs/Observable';
import {Injectable} from "@angular/core";
/**
 * Reference to a dialog opened via the MdDialog service.
 */
@Injectable()
export declare class DrawCanvasRef {
    /** Subject for notifying the user that the dialog has finished closing. */
    private _afterClosed;
    constructor(_overlayRef: OverlayRef);
    /**
     * Close the dialog.
     * @param dialogResult Optional result to return to the dialog opener.
     */
    close(dialogResult?: any): void;
    /**
     * Gets an observable that is notified when the dialog is finished closing.
     */
    afterClosed(): Observable<any>;
}
